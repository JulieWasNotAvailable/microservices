package user

import (
	// "errors"

	"log"

	"github.com/JulieWasNotAvailable/microservices/user/api/presenters"
	"github.com/JulieWasNotAvailable/microservices/user/pkg/entities"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type Repository interface {
	CreateUser(user *entities.User) (*entities.User, error)
	ReadUsers() (*[]presenters.User, error)
	ReadUserById(id uuid.UUID) (*presenters.User, error)
	ReadUserByEmail(email string) (*presenters.User, error)
	UpdateUser(id uuid.UUID, user *presenters.User) (*presenters.User, error)
	DeleteUser(id uuid.UUID) error
}

type repository struct {
	DB *gorm.DB
}

func NewRepo(db *gorm.DB) Repository {
	return &repository{
		DB: db,
	}
}

type GetByEmailRequest struct{
	Email *string
}

// CreateUser implements Repository.
func (r *repository) CreateUser(user *entities.User) (*entities.User, error) {
	id, err := uuid.NewV7()
	if err != nil {
		return nil, err
	}

	user.ID = id

	err = r.DB.Create(&user).Error
	if err != nil {
		return nil, err
	}

	return user, nil
}

func (r *repository) ReadUsers () (*[]presenters.User, error) {
	userModels := &[]presenters.User{}

	err := r.DB.Model(userModels).Preload("Metadata").Find(&userModels).Error
	if err != nil {
		return nil, err
	}

	return userModels, nil
}

func (r *repository) ReadUserById (id uuid.UUID) (*presenters.User, error) {
	user := &presenters.User{}
	log.Println(id)
	err := r.DB.Where("ID = ?", id).Preload("Metadata").First(user).Error

	if err != nil {
		return nil, err
	}

	return user, nil
}

func (r *repository) ReadUserByEmail (email string) (*presenters.User, error) {
	user := &presenters.User{}

	err := r.DB.Where("email = ?", email).Preload("Metadata").First(user).Error

	if err != nil{
		return nil, err
	}

	return user, nil
}

func (r *repository) UpdateUser (id uuid.UUID, user *presenters.User) (*presenters.User, error) {

	err := r.DB.Where("ID = ?", id).Updates(user).Error

	if err != nil{
		return nil, err
	}

	return user, nil
}

func (r *repository) DeleteUser (id uuid.UUID) error {
	userModel := &entities.User{}

	err := r.DB.Delete(userModel, id).Error 

	if err != nil {
		return err
	}

	return nil
}