package main

import (
	"log"

	"github.com/JulieWasNotAvailable/microservices/user/api/routes"
	"github.com/JulieWasNotAvailable/microservices/user/pkg/bmmetadata"
	"github.com/JulieWasNotAvailable/microservices/user/pkg/dbconnection"
	"github.com/JulieWasNotAvailable/microservices/user/pkg/entities"
	"github.com/JulieWasNotAvailable/microservices/user/pkg/user"
	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/cors"
)

func main () {
	
	pgconfig := dbconnection.GetConfigs()
	db, err := dbconnection.NewConnection(pgconfig) 
	if err != nil {
		log.Fatal("Database Connection Error $s", err)
	}
	err = entities.MigrateUser(db)
	if err != nil {
		log.Fatal("Cannot Migrate User Error $s", err)
	}
	err = entities.MigrateMetadata(db)
	if err != nil {
		log.Fatal("Cannot Migrate Metadata Error $s", err)
	}
	err = entities.MigrateRole(db)
	if err != nil {
		log.Fatal("Cannot Migrate Role Error $s", err)
	}

	userRepo := user.NewRepo(db)
	metadataRepo := bmmetadata.NewRepo(db)
	userService := user.NewService(userRepo)
	metadataService := bmmetadata.NewService(metadataRepo)

	app := fiber.New()
	app.Use(cors.New())
	app.Get("/", func(ctx *fiber.Ctx) error {
		return ctx.Send([]byte("Welcome to the clean-architecture postgres user service!"))
	})

	api := app.Group("/api")
	routes.UserRouter(api, userService)
	routes.MetadataRoutes(api, metadataService)
	routes.GoogleRoutes(api)
	routes.WelcomeRouter(api)
	
	app.Listen(":7773")
}