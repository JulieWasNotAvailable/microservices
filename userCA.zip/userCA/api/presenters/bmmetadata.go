package presenters

import (
	"github.com/JulieWasNotAvailable/microservices/user/pkg/entities"
	"github.com/gofiber/fiber/v2"
)

type Metadata struct {
	ID					uint
	VkUrl           	*string `json:"vkUrl,omitempty"`
	TelegramUrl      	*string `json:"telegramUrl,omitempty"`
	InstagramUrl     	*string `json:"instagramUrl,omitempty"`
	Description      	*string `json:"description,omitempty"`
	SubscriptionTypeID 	*int    `json:"subscriptionTypeId,omitempty"`
	UserID 				uint
}

func MetadataSuccessResponse(data *entities.Metadata) *fiber.Map {
	metadata := Metadata{
		VkUrl:            	data.VkUrl,
		TelegramUrl:      	data.TelegramUrl,
		InstagramUrl:     	data.InstagramUrl,
		Description:      	data.Description,
		SubscriptionTypeID: data.SubscriptionTypeID,
		UserID: 			data.UserID,
	}

	return &fiber.Map{
		"status": true,
		"data":   metadata,
		"error":  nil,
	}
}

func MetadataSuccessResponse2 (data *Metadata) *fiber.Map {
	metadata := Metadata {
		ID: 				data.ID,
		VkUrl:            	data.VkUrl,
		TelegramUrl:      	data.TelegramUrl,
		InstagramUrl:     	data.InstagramUrl,
		Description:      	data.Description,
		SubscriptionTypeID: data.SubscriptionTypeID,
	}

	return &fiber.Map{
		"status": true,
		"data":   metadata,
		"error":  nil,
	}
}

func MetadataSuccessResponse3 (data *[]Metadata) *fiber.Map {
	return &fiber.Map{
		"status": true,
		"data":   data,
		"error":  nil,
	}
}

func MetadataErrorResponse(err error) *fiber.Map {
	return &fiber.Map{
		"status": false,
		"data":   "",
		"error":  err.Error(),
	}
}