package presenters

import (
	"github.com/JulieWasNotAvailable/microservices/user/pkg/entities"
	"github.com/gofiber/fiber/v2"
)

type User struct {
	ID				uint
	Email            *string
	Password         *string
	Firstname 		*string
  	Lastname 		*string
  	Patronymic 		*string
  	Username 		*string  
	RoleID          uint
	SubscriptionID  *int
	UsersFavourites *int
	FollowerOf      *int
	Metadata 		Metadata   `gorm:"foreignKey:UserID"`
}

func UserSuccessResponse(data *entities.User) *fiber.Map {
	user := User {
		ID : data.ID,
		Username : data.Username,
		Password : data.Password,
		RoleID : data.RoleID,          
		SubscriptionID  : data.SubscriptionID,
		Email : data.Email,           
		UsersFavourites : data.UsersFavourites,
		FollowerOf : data.FollowerOf,      
	}
	return &fiber.Map{
		"status": true,
		"data":   user,
		"error":  nil,
	}
}

func UserSuccessResponse2 (data *User) *fiber.Map {
	user := User {
		ID : data.ID,
		Username : data.Username,
		Password : data.Password,
		
		RoleID : data.RoleID,          
		SubscriptionID  : data.SubscriptionID,
		Email : data.Email,           
		UsersFavourites : data.UsersFavourites,
		FollowerOf : data.FollowerOf,      
	}
	return &fiber.Map{
		"status": true,
		"data":   user,
		"error":  nil,
	}
}

func UsersSuccessResponse(data *[]User) *fiber.Map {
	return &fiber.Map{
		"status" : true,
		"data" : data,
		"error" : nil,
	}
}

func UserErrorResponse(err error) *fiber.Map {
	return &fiber.Map{
		"status": false,
		"data":   "",
		"error":  err.Error(),
	}
}