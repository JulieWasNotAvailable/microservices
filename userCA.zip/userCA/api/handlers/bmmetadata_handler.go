package handlers

import (
	"errors"
	// "log"
	// "log"
	"net/http"

	"github.com/JulieWasNotAvailable/microservices/user/api/presenters"
	"github.com/JulieWasNotAvailable/microservices/user/pkg/bmmetadata"
	"github.com/JulieWasNotAvailable/microservices/user/pkg/entities"

	"github.com/gofiber/fiber/v2"
)

func AddMetadata(service bmmetadata.Service) fiber.Handler {
	return func(c *fiber.Ctx) error {
		requestBody := entities.Metadata{}
		err := c.BodyParser(&requestBody)

		if requestBody.UserID == 0 {
			c.Status(http.StatusBadRequest)
			return c.JSON(presenters.MetadataErrorResponse(errors.New("UserID is required")))
		} 

		if err != nil {
			c.Status(http.StatusUnprocessableEntity)
			return c.JSON(presenters.MetadataErrorResponse(err))
		}

		result, err := service.InsertMetadata(&requestBody)

		if err != nil {
			c.Status(http.StatusInternalServerError)
			return c.JSON(presenters.MetadataErrorResponse(err))
		}
		return c.JSON(presenters.MetadataSuccessResponse(result))
	}
}

func GetMetadatas(service bmmetadata.Service) fiber.Handler {
	return func(c *fiber.Ctx) error {

		result, err := service.FetchMetadatas()
		if err != nil {
			c.Status(http.StatusInternalServerError)
			return c.JSON(presenters.MetadataErrorResponse(err))
		}

		return c.JSON(presenters.MetadataSuccessResponse3(result))
	}
}

func GetMetadataById(service bmmetadata.Service) fiber.Handler {
	return func(c *fiber.Ctx) error {
		id, err := c.ParamsInt("id")
		if err != nil {
			c.Status(http.StatusBadRequest)
			return c.JSON(presenters.MetadataErrorResponse(errors.New("invalid ID")))
		}

		result, err := service.FetchMetadataById(id)
		if err != nil {
			c.Status(http.StatusInternalServerError)
			return c.JSON(presenters.MetadataErrorResponse(err))
		}

		return c.JSON(presenters.MetadataSuccessResponse2(result))
	}
}

func RemoveMetadata(service bmmetadata.Service) fiber.Handler {
	return func(c *fiber.Ctx) error {
		id, err := c.ParamsInt("id")
		if err != nil {
			c.Status(http.StatusBadRequest)
			return c.JSON(presenters.MetadataErrorResponse(errors.New("invalid ID")))
		}

		err = service.RemoveMetadataById(id)
		if err != nil {
			c.Status(http.StatusInternalServerError)
			return c.JSON(presenters.MetadataErrorResponse(err))
		}

		return c.JSON(&fiber.Map{
			"status": true,
			"data":   "deleted successfully",
			"err":    nil,
		})
	}
}