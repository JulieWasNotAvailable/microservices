package handlers

import (
	"context"
	"log"
	"net/http"
	"os"
	"time"

	"github.com/JulieWasNotAvailable/microservices/user/api/presenters"
	"github.com/JulieWasNotAvailable/microservices/user/internal/middleware"
	"github.com/gofiber/fiber/v2"
	"github.com/golang-jwt/jwt/v5"
	"google.golang.org/api/idtoken"
	"google.golang.org/api/oauth2/v2"
	"google.golang.org/api/option"
)

// Auth fiber handler
func Auth(c *fiber.Ctx) error {
	path := middleware.ConfigGoogle()
	//generates a url for redirection to the google page
	url := path.AuthCodeURL("state")
	log.Println(url)
	return c.Redirect(url)
}

// Callback to receive google's response
func Callback(ctx *fiber.Ctx) error {
	token, err := middleware.ConfigGoogle().Exchange(ctx.Context(), ctx.FormValue("code"))
	
	if err != nil {
		ctx.Status(http.StatusUnauthorized)
		return ctx.JSON(presenters.GoogleOauthErrorResponse(err))
	}

	oauth2Service, err := oauth2.NewService(ctx.Context(), option.WithoutAuthentication())
    if err != nil {
        return err
    }

    tokenInfo, err := oauth2Service.Tokeninfo().AccessToken(token.AccessToken).Do()
    if err != nil {
        return err
    }

    if !tokenInfo.VerifiedEmail {
        return err
    }

	// email := middleware.GetEmail(token.AccessToken)
	return ctx.Status(200).JSON(fiber.Map{"email": tokenInfo.Email, "access token": token})
}

func HandleGoogleAuth(c *fiber.Ctx) error {
	type Data struct {
		Token string `json:"token"`
	}
	
	var json Data
	
	if err := c.BodyParser(&json); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": "Invalid request"})
	}

	// Verify Google token
	config := middleware.ConfigGoogle()
	
	payload, err := idtoken.Validate(context.Background(), json.Token, config.ClientID)
	if err != nil {
		return c.Status(fiber.StatusUnauthorized).JSON(fiber.Map{"error": "Invalid Google token"})
	}

	// Extract user data
	email, _ := payload.Claims["email"].(string)
	name, _ := payload.Claims["name"].(string)
	userId, _ := payload.Claims["sub"].(string)
	log.Println("email: ", email)
	// Generate JWT token
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, jwt.MapClaims{
		"sub":   userId,
		"email": email,
		"name":  name,
		"iat":   time.Now().Unix(),
		"exp":   time.Now().Add(time.Hour * 24).Unix(),
	})

	middleware.LoadENV()
	tokenString, err := token.SignedString([]byte(os.Getenv("SECRET")))
	if err != nil {
		log.Println("error: ", err)
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "Failed to generate token"})
	}
	log.Println("token: ", tokenString)
	return c.JSON(fiber.Map{
		"token": tokenString,
		"user": fiber.Map{
			"id":    userId,
			"email": email,
			"name":  name,
		},
	})
}
