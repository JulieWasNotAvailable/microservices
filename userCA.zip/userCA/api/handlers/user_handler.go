package handlers

import (
	"errors"
	"strings"

	"net/http"

	"github.com/JulieWasNotAvailable/microservices/user/api/presenters"
	"github.com/JulieWasNotAvailable/microservices/user/pkg/entities"
	"github.com/JulieWasNotAvailable/microservices/user/pkg/user"
	"github.com/gofiber/fiber/v2"

	"github.com/golang-jwt/jwt/v5"
)

type MyCustomClaims struct {
	Email string `json:"email"`
	jwt.RegisteredClaims
}

type Username struct {
	Username string
}

func AddUser(service user.Service) fiber.Handler {
	return func (c *fiber.Ctx) error {
		var requestBody entities.User
		err := c.BodyParser(&requestBody)

		requestBody.RoleID = 1

		if *requestBody.Email == "" || *requestBody.Password == "" {
			c.Status(http.StatusInternalServerError)
			return c.JSON(presenters.UserErrorResponse(errors.New(
				"email and password should not be null",
				)))
		}

		if err != nil {
			c.Status(http.StatusUnprocessableEntity)
			return c.JSON(presenters.UserErrorResponse(err))
		}
		
		result, err := service.InsertUser(&requestBody)
		
		if err != nil {
			c.Status(http.StatusInternalServerError)
			return c.JSON(presenters.UserErrorResponse(err))
		}
		return c.JSON(presenters.UserSuccessResponse(result))
	}
}

func GetUsers(service user.Service) fiber.Handler {
	return func(c *fiber.Ctx) error {
		result, err := service.FetchUsers()

		if err != nil {
			c.Status(http.StatusInternalServerError)
			return c.JSON(presenters.UserErrorResponse(err))
		}

		return c.JSON(presenters.UsersSuccessResponse(result))
	}
}

func GetUserById(service user.Service) fiber.Handler {
	return func(c *fiber.Ctx) error {
		id, err := c.ParamsInt("id")

		if err != nil {
			c.Status(http.StatusBadRequest).JSON(&fiber.Map{
				"message":"could not get id",
			})
			return c.JSON(presenters.UserErrorResponse(err))
		}

		result, err := service.FetchUserById(id)
		if err != nil {
			c.Status(http.StatusInternalServerError)
			return c.JSON(presenters.UserErrorResponse(err))
		}

		return c.JSON(presenters.UserSuccessResponse2(result))
	}
}

func GetUserByEmail(service user.Service) fiber.Handler {
	return func(c *fiber.Ctx) error {
		email := c.Query("email")
		
		if email == "" {
			c.Status(http.StatusBadRequest)
			return c.JSON(presenters.UserErrorResponse(errors.New(
				"please, specify email",
				)))
		}

		result, err := service.FetchUserByEmail(&email)

		if err != nil{
			c.JSON(http.StatusInternalServerError)
			return c.JSON(presenters.UserErrorResponse(err))
		}

		return c.JSON(presenters.UserSuccessResponse2(result))
	}
}

func GetBeatmakerByJWT(service user.Service) fiber.Handler {
	return func(c *fiber.Ctx) error {
		auth := c.GetReqHeaders()
		authHeader := auth["Authorization"]
		splitToken := strings.Split(authHeader[0], "Bearer ")
		tokenStr := splitToken[1]

		token, _, err := jwt.NewParser().ParseUnverified(tokenStr, jwt.MapClaims{})
		if err != nil {
			return err
		}

		claims, ok := token.Claims.(jwt.MapClaims)
		if !ok {
			return errors.New("couldn't parse")
		}

		email, ok := claims["email"].(string)

		user, err := service.FetchUserByEmail(&email)

		if err != nil {
			return err
		}

		return c.JSON(presenters.UserSuccessResponse2(user))
	}
}

func UpdateUser(service user.Service) fiber.Handler {
	return func(c *fiber.Ctx) error {
		var requestBody presenters.User
		err := c.BodyParser(&requestBody)
		requestBody.RoleID = 2

		if err != nil {
			return err
		}

		token := c.Locals("user").(*jwt.Token)
		claims := token.Claims.(jwt.MapClaims)
		email := claims["email"].(string)
		result, err := service.UpdateUser(&email, &requestBody)

		if err != nil {
			c.Status(http.StatusInternalServerError)
			return c.JSON(presenters.UserErrorResponse(err))
		}
	
		return c.JSON(presenters.UserSuccessResponse2(result))
	}
}

func UserIsBeatmaker (service user.Service) fiber.Handler {
	return func(c *fiber.Ctx) error {
		token := c.Locals("user").(*jwt.Token)
		claims := token.Claims.(jwt.MapClaims)
		email := claims["email"].(string)
		user := presenters.User{
			RoleID: 2,
		}

		_, err := service.UpdateUser(&email, &user)

		if err != nil {
			c.Status(http.StatusInternalServerError)
			return c.JSON(presenters.UserErrorResponse(err))
		}

		return c.JSON(&fiber.Map{
			"status": true,
			"data":   "updated successfully",
			"err":    nil,
		})	
	}
}

func RemoveUser(service user.Service) fiber.Handler {
	return func(c *fiber.Ctx) error {
		token := c.Locals("user").(*jwt.Token)
		claims := token.Claims.(jwt.MapClaims)
		email := claims["email"].(string)

		err := service.RemoveUser(&email)

		if err != nil {
			c.Status(http.StatusInternalServerError)
			return c.JSON(presenters.UserErrorResponse(err))
		}

		return c.JSON(&fiber.Map{
			"status": true,
			"data":   "updated successfully",
			"err":    nil,
		})		
	}
}

func PostBeatMock(c *fiber.Ctx) error {
	return c.JSON(&fiber.Map{
		"status": true,
		"data":   "congrats! you posted the beat!",
		"err":    nil,
	})
}