package routes

import (
	"github.com/JulieWasNotAvailable/microservices/user/api/handlers"

	"github.com/gofiber/fiber/v2"
)

// Routes for fiber
func GoogleRoutes(app fiber.Router) {
	app.Get("/google", handlers.Auth)
	app.Get("/auth/google/callback", handlers.Callback)
	app.Post("/auth/google/getjwt", handlers.HandleGoogleAuth)
}
