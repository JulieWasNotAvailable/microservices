package routes

import (
	"github.com/JulieWasNotAvailable/microservices/user/api/handlers"
	"github.com/JulieWasNotAvailable/microservices/user/internal/middleware"
	"github.com/JulieWasNotAvailable/microservices/user/pkg/bmmetadata"
	"github.com/gofiber/fiber/v2"
)

func MetadataRoutes(app fiber.Router, service bmmetadata.Service) {
    app.Post("/metadata", handlers.AddMetadata(service))
    app.Get("/metadatas", handlers.GetMetadatas(service)) 
    app.Get("/metadataById/:id", handlers.GetMetadataById(service))
    app.Delete("/metadataById/:id", middleware.Protected(), handlers.RemoveMetadata(service))
}
