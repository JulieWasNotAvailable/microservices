package routes

import (
	"github.com/JulieWasNotAvailable/microservices/user/api/handlers"
	"github.com/JulieWasNotAvailable/microservices/user/internal/middleware"
	"github.com/JulieWasNotAvailable/microservices/user/pkg/user"

	"github.com/gofiber/fiber/v2"
)

func UserRouter(app fiber.Router, service user.Service) {
	app.Post("/user", handlers.AddUser(service))
	app.Get("/users", handlers.GetUsers(service))
	app.Get("/userById/:id", handlers.GetUserById(service))
	app.Get("/userByEmail/", middleware.ProtectedRequiresModerator(), handlers.GetUserByEmail(service))
	app.Delete("/userById/:id", middleware.Protected(), handlers.RemoveUser(service))

	app.Post("/userIsBeatmaker", middleware.Protected(), handlers.UserIsBeatmaker(service))
	app.Patch("/user", middleware.Protected(), handlers.UpdateUser(service))
	app.Get("/beatmakerByJWT", middleware.Protected(), handlers.GetBeatmakerByJWT(service))
	
	app.Post("/login", middleware.Login(service))
	app.Post("/register", middleware.Register(service))
	app.Post("/postNewBeatMock", middleware.ProtectedRequiresBeatmaker(), handlers.PostBeatMock)
}
