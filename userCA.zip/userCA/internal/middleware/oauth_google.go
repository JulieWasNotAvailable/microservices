package middleware

import (
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"net/url"
	"os"

	"github.com/JulieWasNotAvailable/microservices/user/api/presenters"
	"golang.org/x/oauth2"
	"golang.org/x/oauth2/google"
)

// Config exported via godotenv
func Config(key string) string {
	return os.Getenv(key)
}

// ConfigGoogle to set config of oauth
func ConfigGoogle() *oauth2.Config {
	conf := &oauth2.Config{
		ClientID:     Config("Client"),
		ClientSecret: Config("Secret"),
		RedirectURL:  Config("redirect_url"),
		Scopes: []string{
			"https://www.googleapis.com/auth/userinfo.email",
		}, // you can use other scopes to get more data
		Endpoint: google.Endpoint,
	}
	return conf
}



// GetEmail of user
func GetEmail(token string) presenters.GoogleResponse {
	reqURL, err := url.Parse("https://www.googleapis.com/oauth2/v1/userinfo")
	if err != nil {
		panic(err)
	}
	log.Println(reqURL)
	ptoken := fmt.Sprintf("Bearer %s", token)
	req := &http.Request{
		Method: "GET",
		URL:    reqURL,
		Header: map[string][]string{
			"Authorization": {ptoken},
		},
	}

	res, err := http.DefaultClient.Do(req)
	if err != nil {
		panic(err)
	}
	defer res.Body.Close()
	body, err := io.ReadAll(res.Body)
	if err != nil {
		panic(err)
	}
	var data presenters.GoogleResponse
	err = json.Unmarshal(body, &data)
	if err != nil {
		panic(err)
	}
	return data
}

