package middleware

import (
	"errors"
	"log"
	"net/http"
	"os"
	"time"

	"github.com/JulieWasNotAvailable/microservices/user/api/presenters"
	"github.com/JulieWasNotAvailable/microservices/user/pkg/entities"
	"github.com/JulieWasNotAvailable/microservices/user/pkg/user"
	"github.com/gofiber/fiber/v2"
	"github.com/golang-jwt/jwt/v5"
	"github.com/joho/godotenv"
	"gorm.io/gorm"
)

func Register(service user.Service) fiber.Handler {
	return func(c *fiber.Ctx) error {
		input := entities.User{}		
		input.RoleID = 1
		
		err := c.BodyParser(&input)
		if err != nil {
			c.Status(http.StatusUnprocessableEntity)
			return c.JSON(presenters.UserErrorResponse(err))
		}

		result, err := service.FetchUserByEmail(input.Email)
		
		if (err != nil) && !(errors.Is(err, gorm.ErrRecordNotFound)) {
			c.Status(http.StatusInternalServerError)
			return c.JSON(presenters.UserErrorResponse(err))
		}

		if result != nil {
			c.Status(http.StatusConflict)
			return c.JSON(errors.New("user already exists"))
		}
		
		_, err = service.InsertUser(&input)

		if err != nil {
			c.Status(http.StatusInternalServerError)
			return c.JSON(presenters.UserErrorResponse(err))
		}

		token := jwt.New(jwt.SigningMethodHS256)
		claims := token.Claims.(jwt.MapClaims)
		claims["email"] = input.Email
		claims["role"] = input.RoleID
		claims["exp"] = time.Now().Add(time.Hour * 72).Unix()		

		err = godotenv.Load(".env")
		if err != nil {
			log.Fatal(err)
		}

		t, err := token.SignedString([]byte(os.Getenv("SECRET")))
		if err != nil {
			return c.SendStatus(fiber.StatusInternalServerError)
		}

		return c.JSON(fiber.Map{"status": "success", "message": "Successfully registered", "data": t})
	}
}