package entities

import (
	"errors"

	"gorm.io/gorm"
)

type User struct {
	ID				uint
	Email            *string `gorm:"unique"`
	Password         *string

	Firstname 		*string
  	Lastname 		*string
  	Patronymic 		*string
	
  	Username 		*string `gorm:"unique"`
	RoleID 			uint 	//`gorm:"default:1"` 
	SubscriptionID   *int 
	UsersFavourites  *int   
	FollowerOf       *int
	Metadata  	 	Metadata   `gorm:"foreignKey:UserID;constraint:OnDelete:CASCADE;"`
}

func MigrateUser(db *gorm.DB) error {
	err := db.AutoMigrate(&User{})
	return err
}

// Validate - кастомная валидация
func (u *User) Validate() error {
	if u.RoleID != 1 && u.RoleID != 2 && u.RoleID != 3 {
		return errors.New("roleID must be 1, 2, or 3")
	}
	return nil
}

// BeforeSave - хуки GORM для автоматической валидации
func (u *User) BeforeSave(tx *gorm.DB) error {
	return u.Validate()
}