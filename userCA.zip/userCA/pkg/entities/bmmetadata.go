package entities

import "gorm.io/gorm"

type Metadata struct {
	ID					uint
	VkUrl           	*string `json:"vkUrl,omitempty"`
	TelegramUrl      	*string `json:"telegramUrl,omitempty"`
	InstagramUrl     	*string `json:"instagramUrl,omitempty"`
	Description      	*string `json:"description,omitempty"`
	SubscriptionTypeID 	*int    `json:"subscriptionTypeId,omitempty"`
	UserID 				uint
}

func MigrateMetadata(db *gorm.DB) error {
	err := db.AutoMigrate(&Metadata{})
	return err
}