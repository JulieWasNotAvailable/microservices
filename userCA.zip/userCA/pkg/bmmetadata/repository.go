package bmmetadata

import (
	"log"

	"github.com/JulieWasNotAvailable/microservices/user/api/presenters"
	"github.com/JulieWasNotAvailable/microservices/user/pkg/entities"
	"gorm.io/gorm"
)

type Repository interface {
	CreateMetadata(metadata *entities.Metadata) (*entities.Metadata, error)
	ReadMetadatas() (*[]presenters.Metadata, error)
	ReadMetadataById(id int) (*presenters.Metadata, error)
	DeleteMetadataById(id int) error
}

type repository struct {
	DB *gorm.DB
}

func NewRepo(db *gorm.DB) Repository {
	return &repository{
		DB: db,
	}
}

func (r *repository) CreateMetadata(metadata *entities.Metadata) (*entities.Metadata, error) {
	result := r.DB.Create(&metadata)

	if result.Error != nil {
		return nil, result.Error
	}
	log.Println(metadata.ID)
	log.Println(result)

	return metadata, nil
}

func (r *repository) ReadMetadatas() (*[]presenters.Metadata, error) {
	metadatasModel := &[]presenters.Metadata{}

	err := r.DB.Find(&metadatasModel).Error
	// err := db.Model(&User{}).Preload("CreditCard").Find(&users).Error

	if err != nil {
		return nil, err
	}

	return metadatasModel, nil
}

func (r *repository) ReadMetadataById(id int) (*presenters.Metadata, error) {
	metadata := &presenters.Metadata{}

	err := r.DB.First(&metadata, id).Error	
	
	if err != nil {
		return nil, err
	}

	return metadata, nil
}

func (r *repository) DeleteMetadataById(id int) error {
	metadata := &entities.Metadata{}

	err := r.DB.Delete(metadata, id).Error

	if err != nil {
		return err
	}

	return nil
}