package user

import (
	// "errors"

	"github.com/JulieWasNotAvailable/microservices/user/api/presenters"
	"github.com/JulieWasNotAvailable/microservices/user/pkg/entities"
	"gorm.io/gorm"
)

type Repository interface {
	CreateUser(user *entities.User) (*entities.User, error)
	ReadUsers() (*[]presenters.User, error)
	ReadUserById(id int) (*presenters.User, error)
	ReadUserByEmail(email *string) (*presenters.User, error)
	UpdateUser(email *string, user *presenters.User) (*presenters.User, error)
	DeleteUser(email *string) error
}

type repository struct {
	DB *gorm.DB
}

func NewRepo(db *gorm.DB) Repository {
	return &repository{
		DB: db,
	}
}

type GetByEmailRequest struct{
	Email *string
}

// CreateUser implements Repository.
func (r *repository) CreateUser(user *entities.User) (*entities.User, error) {
	err := r.DB.Create(&user).Error
	if err != nil {
		return nil, err
	}

	return user, nil
}

func (r *repository) ReadUsers () (*[]presenters.User, error) {
	userModels := &[]presenters.User{}

	err := r.DB.Model(userModels).Preload("Metadata").Find(&userModels).Error
	if err != nil {
		return nil, err
	}

	return userModels, nil
}

func (r *repository) ReadUserById (id int) (*presenters.User, error) {
	user := &presenters.User{}

	err := r.DB.Where("ID = ?", id).Preload("Metadata").First(user).Error

	if err != nil {
		return nil, err
	}

	return user, nil
}

func (r *repository) ReadUserByEmail (email *string) (*presenters.User, error) {
	user := &presenters.User{}

	err := r.DB.Where("email = ?", *email).Preload("Metadata").First(user).Error

	if err != nil{
		return nil, err
	}

	return user, nil
}

func (r *repository) UpdateUser (email *string, user *presenters.User) (*presenters.User, error) {

	err := r.DB.Where("email = ?", *email).Updates(user).Error

	if err != nil{
		return nil, err
	}

	return user, nil
}

func (r *repository) DeleteUser (email *string) error {
	userModel := &entities.User{}

	err := r.DB.Delete(userModel, *email).Error 

	if err != nil {
		return err
	}

	return nil
}