package user

import (
	"github.com/JulieWasNotAvailable/microservices/user/api/presenters"
	"github.com/JulieWasNotAvailable/microservices/user/pkg/entities"
)

type Service interface {
	InsertUser(user *entities.User) (*entities.User, error)
	FetchUsers() (*[]presenters.User, error)
	FetchUserById(id int) (*presenters.User, error)
	FetchUserByEmail(email *string) (*presenters.User, error)
	UpdateUser(email *string, user *presenters.User) (*presenters.User, error)
	RemoveUser(email *string) error
}

type service struct {
	repository Repository
}

func NewService(r Repository) Service {
	return &service{
		repository: r,
	}
}

// InsertUser implements Service.
func (s *service) InsertUser(user *entities.User) (*entities.User, error) {
	return s.repository.CreateUser(user)
}

// FetchUsers implements Service.
func (s *service) FetchUsers() (*[]presenters.User, error) {
	return s.repository.ReadUsers()
}

// FetchUserById implements Service.
func (s *service) FetchUserById(id int) (*presenters.User, error) {
	return s.repository.ReadUserById(id)
}

// FetchUserByEmail implements Service.
func (s *service) FetchUserByEmail(email *string) (*presenters.User, error) {
	return s.repository.ReadUserByEmail(email)
}

//UpdateUser implements Service.
func (s *service) UpdateUser(email *string, user *presenters.User) (*presenters.User, error) {
	return s.repository.UpdateUser(email, user)
}

// RemoveUser implements Service.
func (s *service) RemoveUser(email *string) error {
	return s.repository.DeleteUser(email)
}

// NewService is used to create a single instance of the service
